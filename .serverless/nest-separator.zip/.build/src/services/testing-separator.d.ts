declare function stringSeparator(data: string): object;
