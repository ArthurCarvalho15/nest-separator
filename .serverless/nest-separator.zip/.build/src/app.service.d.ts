export declare class AppService {
    getHello(name: string): string;
}
