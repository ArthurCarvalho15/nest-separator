export declare class SeparatorService {
    stringSeparator(data: string): object;
}
